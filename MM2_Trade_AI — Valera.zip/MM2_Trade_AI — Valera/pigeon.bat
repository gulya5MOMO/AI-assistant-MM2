@echo off
cd /d "%USERPROFILE%\Desktop\MM2_Trade_AI"
start "" "%LOCALAPPDATA%\Programs\Python\Python314\pythonw.exe" "main.pyw" --hidden